package main

type Editable struct {
	i int
	j int
}

func (e *Editable) addI() {
	e.i += 1
}
/*
func (e Editable) copy() (int, int) {
	return e.i, e.j
}

func pumpUp(editable *Editable) {
	editable.i = 1000
}*/
/*
var pow_s = []Editable{
	{ i : 1 }, { i : 2 }, { i : 3 }, { i : 4 },
}*/

func increment(e *Editable) {
	e.i += 1
}

func main() {
	/*for _, pow_ := range pow_s {
		pow_.addI(10)
		var z = Editable{}
		//fmt.Printf("i: %d, pow_: %d\n", i, pow_)
		pumpUp(&pow_)
		pumpUp(&z)
		//i2 := &i
		pow_.addI(10)

		_, _ = pow_.copy()
		
		pow_.j = 1234
		//fmt.Printf("%v", i2)
		//fmt.Printf("After update i: %d, pow_: %d\n", i, pow_)
	}*/

	/*var powS = []Editable{
		{ i : 1 }, { i : 2 }, { i : 3 }, { i : 4 },
	}

	var pow Editable
	for _, pow = range powS {
		increment(&pow)
		pow.addI()
	}*/

	var powS = []Editable{
		{ i : 1 }, { i : 2 }, { i : 3 }, { i : 4 },
	}

	var pow = Editable{}

	for _, pow := range powS {
		increment(&pow)
		
	}
/*
	for range powS {

	}*/
}