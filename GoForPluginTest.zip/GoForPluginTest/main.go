package main

import "fmt"

type editable struct {
	i int
}

type wrap_editable struct {
	editable editable
}

func (e *editable) Increment() {
	fmt.Printf("Before change %v\n", e)
	e.i += 1
	fmt.Printf("After change %v\n", e)
}

/*func increment(e *editable) {
	e.i += 10001
}*/

func mute(e editable) {

}

func main() {
	a := []editable{
		{i: 1}, {i: 2}, {i: 3}, {i: 4},
	}

	b := map[string]editable{
		"1": {i: 10}, "2": {i: 11},
	}

	var e editable
	for i := range b {
		fmt.Println(i)
	}
	for i := 0; i < 10; i++ {

	}

	for _, _ = range a {

	}

	for _, e := range a {
		z := wrap_editable{editable: e}
		e.Increment()
		k := 1
		k += 1
		if k != 1 {
			mute(e)
		}
		increment(&z.editable)
	}

	var e2 editable
	for _, e2 := range b {
		e2.Increment()
	}

	for _, e3 := range b {
		e3.Increment()
		mute(e3)
		increment(&e3)
	}

	/*for i, e3 := range b {
		fmt.Printf("Before changed Expected: %v, Actual %v\n", *e3, *b[i])
		increment(e3)
		fmt.Printf("Expected: %v, Actual %v\n", *e3, *b[i])
	}*/

	fmt.Println(e)
	fmt.Println(a)
	fmt.Println(b)
	fmt.Println(e2)
	e2.Increment()
	fmt.Println(e2)
}