package main

/*type Editable struct {
	i int
}

var pow_s = []Editable{
	{ i : 1 }, { i : 2 }, { i : 3 }, { i : 4 },
}*/

/*func main() {
	for i, pow_ := range pow_s {
		fmt.Printf("i: %d, pow_: %d\n", i, pow_)
	}
}*/
