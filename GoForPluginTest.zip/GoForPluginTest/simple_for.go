package main

import "fmt"

func main() {
	for i := 0; i < 4; i++ {
		fmt.Printf("i: %d\n", i)
	}
}
