package main

/*import "fmt"

type Editable struct {
	i int
}

var pow_s = []Editable{
	{ i : 1 }, { i : 2 }, { i : 3 }, { i : 4 },
}

func (e *Editable) increment() {
	e.i += 1
}

func main() {
	for i := range pow_s {
		pow_ := &pow_s[i]
		fmt.Printf("i: %d, pow_: %d\n", i, pow_)
		pow_.i = 1400
		fmt.Printf("After update i: %d, pow_: %d\n", i, pow_)
	}

	for i, pow_ := range pow_s {
		fmt.Printf("After completion i: %d, pow_: %d\n", i, pow_)
	}
}*/